/**
 * @file
 * SimpleAds blocks JS.
 */

(function ($) {
  Drupal.behaviors.simpleadsBlocks = {
    attach: function(context) {

    }
  };
}(jQuery));