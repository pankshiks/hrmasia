<?php

/**
 * @file
 * SimpleAds Campaigns API.
 */

/**
 * Implements hook_simpleads_campaign_complete().
 *
 * @node - Advertisement node object
 * @campaign - Advertisement campaign node object.
 */
function hook_simpleads_campaign_complete($node, $campaign) {

}
