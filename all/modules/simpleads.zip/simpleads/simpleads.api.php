<?php

/**
 * @file
 * SimpleAds API.
 */

/**
 * Implements hook_insert_click().
 */
function hook_insert_click($node, $ip_address) {

}

/**
 * Implements hook_insert_impression().
 */
function hook_insert_impression($node, $ip_address) {

}

/**
 * Implements hook_simpleads_activate().
 */
function hook_simpleads_activate($node) {

}

/**
 * Implements hook_simpleads_expired().
 */
function hook_simpleads_expired($node) {

}

/**
 * Implements hook_simpleads_types_alter().
 */
function hook_simpleads_types_alter(&$types) {

}
