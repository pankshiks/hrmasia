<?php

/**
 * @file
 * Text advertisement
 * simpleads-type-text.tpl.php
 */

?>
<div class="<?php print $css_classes; ?>" data-id="<?php print $entity->nid; ?>">
  <?php print $output; ?>
</div>
