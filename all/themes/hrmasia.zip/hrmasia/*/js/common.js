 jQuery(document).ready(function () {
    jQuery('.views-field-nothing, .view-article-category-subcategory .item-list, .past-events .views-row').matchHeight();
    });