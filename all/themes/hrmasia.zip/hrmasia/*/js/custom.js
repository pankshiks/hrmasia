 jQuery(document).ready(function () {
	var tvWidth = jQuery('.front .view-hrm-tv.view-display-id-block .views-field-field-video-code').width();
	jQuery('.front .view-hrm-tv.view-display-id-block .views-field-field-video-code iframe').css('width', tvWidth);
	jQuery( window ).resize(function() {
		var tvWidth = jQuery('.front .view-hrm-tv.view-display-id-block .views-field-field-video-code').width();
		jQuery('.front .view-hrm-tv.view-display-id-block .views-field-field-video-code iframe').css('width', tvWidth);
	});
});

//off the autoplay of video on html load ready state
jQuery(document).ready(function () {
	jQuery( "iframe" ).each(function( index ) {
		var str = jQuery( this ).attr("src").replace('autoplay=1', 'autoplay=0');
		jQuery( this ).attr("src",str);
	});
});

//off the autoplay of video on ajaxstop state
jQuery(document).ajaxStop(function() {
	jQuery( "iframe" ).each(function( index ) {
		var str = jQuery( this ).attr("src").replace('autoplay=1', 'autoplay=0');
		jQuery( this ).attr("src",str);
	});
});
// hide when user not login for menu
jQuery(document).ready(function(){
	jQuery('.not-logged-in .condition-list').parent().remove();
	jQuery('.not-logged-in .user-signup').css('border','0px');
	jQuery('.not-logged-in .user-signup').css('margin-left','0px');
	jQuery('.not-logged-in .user-signup').css('padding-left','0px');
});