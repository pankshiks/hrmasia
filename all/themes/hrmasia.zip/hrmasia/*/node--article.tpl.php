 
<div id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?> clearfix"<?php print $attributes; ?>>
  <?php global $user; ?>
  <?php print $user_picture; ?>



  <?php if ($display_submitted): ?>
    <div class="submitted">
      <?php print $submitted; ?>
    </div>
  <?php endif; ?>

  <div class="content"<?php print $content_attributes; ?>>
    <?php
      // We hide the comments and links now so that we can render them later.
      hide($content['comments']);
      hide($content['links']);
	  $share_block = module_invoke('sharethis','block_view','sharethis_block');
	  $subscribe_block = module_invoke('notifications_ui','block_view','subscriptions');

    ?>
      <div class="acticle-top">
    <!--<div class="post-category"> <?php print render($content['field_category']); ?> </div>-->
    <div class="post-title"> <h1> <?php print $node->title; ?> </h1> 
    
    <div class="social-share-post"> <?php print render($share_block['content']); ?> </div>
    </div>
    
    <div class="author-date"> <span class="author"><?php print render($content['field_author_name']);  ?></span> - <span class="post-date"><?php print render($content['field_date']) ;?></span> </div>
      </div>
    
    
      <div class="post-image img-responsive"> <?php print render($content['field_image']); ?> </div>
      <div class="post-summary"> <?php print render($node->body[$node->language][0]['safe_summary']);  ?> </div>
    <?php if($user->uid) { ?>
    	<div class="post-body"> 
        <i>
          <?php
            print render($content['field_article_summary']); 
          ?>
        </i>
    		<?php
    			print render($content['body']); 
    		?> 
    	</div>
    <?php } else { 
//GSI codes
      $string = trim($node->body['und'][0]['safe_value']);
      $stringCut = substr($string, 0, 950);
      $string = substr($stringCut, 0, strrpos($stringCut, '.')).".</p>"; 
      print '<div class="post-body content-padding"><i>' . render($content['field_article_summary']) .'</i>'. $string . '</div>';
/*
//EA codes        
        print '<div class="post-body content-padding">' . strip_tags(substr($node->body['und'][0]['value'],0,600)) . '</div>';
*/		
		print '<div class="subscribe-block">';
		print l('Login','user/login', array('query' => array('destination' => $_GET['q']))). ' in as subscriber to read the full article. <br/>Not a Subscriber Yet? Register Now!';
		print '<div class="subscribebutton">' . l('SUBSCRIBE FOR FREE', 'user/register', array('query' => array('destination' => $_GET['q']))). '</div>';
		print '</div>';    
				
	} ?>    
    <div class="related-articles">
        <?php 
		if ($node->field_category){
			print views_embed_view('related_post','block',$node->field_category['und'][0]['tid']); 
		}
	?> 
    </div>
    
    <div class="disqus-block"> <?php print render($content['disqus']); ?>  
    
  </div>
  
  <?php print render($content['links']); ?>
  <?php print render($content['comments']); ?>

</div>
</div>