 
<div id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?> clearfix"<?php print $attributes; ?>>

  <?php print $user_picture; ?>

  <?php print render($title_prefix); ?>
  <?php if (!$page): ?>
    <h2<?php print $title_attributes; ?>><a href="<?php print $node_url; ?>"><?php print $title; ?></a></h2>
  <?php endif; ?>
  <?php print render($title_suffix); ?>

  <?php if ($display_submitted): ?>
    <div class="submitted">
      <?php print $submitted; ?>
    </div>
  <?php endif; ?>

  <div class="content"<?php print $content_attributes; ?>>
    <?php
      // We hide the comments and links now so that we can render them later.
      hide($content['comments']);
      hide($content['links']);
	  $share_block = module_invoke('sharethis','block_view','sharethis_block');
	  $searchjob = module_invoke('views','block_view','-exp-jobs_list-page');
	  
	  $company = node_load($node->field_company_ref['und'][0]['nid']); 
		$company_logourl = $company ->field_image['und'][0]['uri']; 
		//$style = 'medium';
		//dpm(file_create_url($company_logourl));
	?>

      <h1 class="title"><span>Jobs</span></h1>
   <div class="searchjobform"> 
       <?php print render($searchjob['content']); ?> </div>
   <div class="custom-job-page content-padding clearfix">
         <div class="post-title"> <h1> <?php print $node->title; ?> </h1> </div>
       <div class="post-top clearfix">
           <div class="post-top-left">
  
    <div class="author-date"> <?php print render($content['field_date']) ;?> </div>
    <div class="post-company"> <?php print $company->title; ?> </div>
    <div class="post-region"> <?php print render($content['field_region']); ?> </div> 
        <div class="post-email"> <?php print render($content['field_apply_email_address']); ?> </div>
    <div class="post-salary"> <?php print render($content['field_salary']); ?> </div> 
           </div>
           <?php
              if ( !empty ( $company_logourl ) ) {
            ?>
              <div class="post-image"> <img src="<?php print file_create_url($company_logourl); ?>"> </div>
            <?php
              }
           ?>
       </div>
 
    <div class="post-body"> <?php print render($content['body']); ?> </div>
    
   <div class="applynow"> <a class="button" href=mailto:<?php print $node->field_apply_email_address['und'][0]['email']; ?> target="_top"> Apply Now</a> </div>
   </div>
  </div>
  
  <?php print render($content['links']); ?>
  <?php print render($content['comments']); ?>

</div>
