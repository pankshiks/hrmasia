 <div id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?> clearfix"<?php print $attributes; ?>>

  <?php print $user_picture; ?>

  <?php print render($title_prefix); ?>
  <?php if (!$page): ?>
    <h2<?php print $title_attributes; ?>><a href="<?php print $node_url; ?>"><?php print $title; ?></a></h2>
  <?php endif; ?>
  <?php print render($title_suffix); ?>

  <?php if ($display_submitted): ?>
    <div class="submitted">
      <?php print $submitted; ?>
    </div>
  <?php endif; ?>

  <div class="content"<?php print $content_attributes; ?>>
    <?php
      // We hide the comments and links now so that we can render them later.
      hide($content['comments']);
      hide($content['links']);
	  $share_block = module_invoke('sharethis','block_view','sharethis_block');
	  $subscribe_block = module_invoke('notifications_ui','block_view','subscriptions');
    ?>
    <div class="acticle-top">
    <!--<div class="post-category"> <?php print render($content['field_tags']); ?> </div>-->
    <div class="post-title"> <h1> <?php print $node->title; ?> </h1> 
    
     <div class="social-share-post"> <?php print render($share_block['content']); ?> </div>
    </div>
    
    <div class="author-date"> <span class="author"><?php print $name;  ?></span> - <span class="post-date"><?php print render($content['field_date']) ;?></span> </div>
    </div>
   
    <div class="post-image img-responsive"> <?php print render($content['field_image']); ?> </div>
    <div class="post-summary content-padding"> <?php print render($node->field_news_summary['und'][0]['value']);  ?> </div>
        <?php if($user->uid) { ?>
    	<div class="post-body"> <?php print render($content['body']); ?> </div>
		<?php } else { 
//GSI codes
			$string = trim($node->body['und'][0]['safe_value']);
			$stringCut = substr($string, 0, 950);
			$string = substr($stringCut, 0, strrpos($stringCut, '.')).".</p>"; 
			print '<div class="post-body content-padding">' . $string . '</div>';
/*
//EA codes
			$string = $node->body['und'][0]['value'];

			$string = preg_replace('/\n{2,}/', "</p><p>", trim($string));
			//$string = preg_replace('/\n/', '<br>',$string);
			$string = "<p>{$string}</p>";

			$stringCut = substr($string, 0, 1200);
			$string = substr($stringCut, 0, strrpos($stringCut, '.'))."."; 
			//		echo $string;
			
			print '<div class="post-body content-padding">' . $string . '</div>';
			
			//print '<div class="post-body content-padding">' . strip_tags(substr($node->body['und'][0]['value'],0,600)) . '</div>';
*/
            print '<div class="subscribe-block">';
            print l('Login','user/login', array('query' => array('destination' => $_GET['q']))). ' in as subscriber to read the full article. <br/>Not a Subscriber Yet? Register Now!';
            print '<div class="subscribebutton">' . l('SUBSCRIBE FOR FREE', 'user/register', array('query' => array('destination' => $_GET['q']))). '</div>';
            print '</div>';    
                    
        } ?>   
     
	
	<!-- Add pager at the bottom -->
    <div class="news-pager related-articles">
        <ul>
            <li class="views-row-odd">
   <?php 
		if($content['flippy_pager']['#list']['prev']['nid']){
			print render(prev_next('prev', $content['flippy_pager']['#list']['prev']['nid']));
                        }?></li>
            <li class="views-row-even"> <?php 
		if($content['flippy_pager']['#list']['next']['nid']){
			print render(prev_next('next', $content['flippy_pager']['#list']['next']['nid']));
		}
                ?></li>
	
        </ul>
    </div>


	<!--
	<div class="related-articles">
	<?php 
		if ($node->field_tags){
			print views_embed_view('related_post','block_2',$node->field_tags['und'][0]['tid']); 
		}
	?> 
     </div>-->
    
    <div class="disqus-block"> <?php print render($content['disqus']); ?>  </div>
    
  </div>
  
  <?php print render($content['links']); ?>
  <?php print render($content['comments']); ?>

</div>