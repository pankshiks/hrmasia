 <?php
?>
<div id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?> clearfix"<?php print $attributes; ?>> <?php print $user_picture; ?> <?php print render($title_prefix); ?>
  <?php if (!$page): ?>
	<h2<?php print $title_attributes; ?>><a href="<?php print $node_url; ?>"><?php print $title; ?></a></h2>
  <?php endif; ?>
  <?php print render($title_suffix); ?>
  <?php if ($display_submitted): ?>
	<div class="submitted"> <?php print $submitted; ?> </div>
  <?php endif; ?>
  <div class="content"<?php print $content_attributes; ?>>
    <?php
      // We hide the comments and links now so that we can render them later.
      hide($content['comments']);
      hide($content['links']);
	  $share_block = module_invoke('sharethis','block_view','sharethis_block');
	  $searchjob = module_invoke('views','block_view','-exp-courses-page');
    ?>
    <div class="course-top" style="margin-bottom: 2em;">
      <h1 class="title"><span>Course Details</span></h1>
      <!--
		<div class="searchjobform"> 
       <?php //print render($searchjob['content']); ?> 
	    </div>
		--> 
	  <a class="button" style="background: #a8b2b2;text-transform:none;" href="/courses-categories">Back to All Courses</a>
    </div>
    <div class="custom-job-page content-padding clearfix" style="padding:0;">
      <div class="post-title" style="color: #be202e;font-size: 30px;margin-bottom: 0.5em;line-height: 1em;"><?php print $node->title; ?></div>
	  <div class="author-date"><?php print date('d M Y',strtotime($content['field_course_dates']['#items'][0]['value'])).' - '.date('d M Y',strtotime($content['field_course_dates']['#items'][0]['value2'])); ?></div>
	  <div class="post-company" style="text-transform:uppercase;font-size: 14px;color: #242424;font-weight: bold;"><?php print node_load($content['field_trainining_company']['#items'][0]['nid'])->title; ?></div>
      <div style="margin:1em 0;">
		  <div class="post-region"> <?php print render($content['field_location']); ?> </div>
		  <div class="post-email"> <?php print render($content['field_contact_us_email']); ?> </div>
		  <div class="post-salary"> <?php print render($content['field_salary']); ?> </div>
		  <div class="post-region"> <?php print render($content['field_training_provider']); ?> </div>
		  <?php if (isset($content['field_cost2']) && !empty($content['field_cost2'])) { ?>
			<div class="post-cost"> <?php print render($content['field_cost2']); ?> </div>
		  <?php } else { ?>
			<div class="post-cost"> <?php print render($content['field_cost']); ?> </div>
		  <?php } ?>		  
		  <div class="post-certification"> <?php print render($content['field_certification']); ?> </div>		  
		  <?php if (isset($content['field_register_link_url']['#items'][0]['url']) && !empty($content['field_register_link_url']['#items'][0]['url'])) { ?>
		  <div class="post-url"><strong>Course URL: </strong><a href="<?php print $content['field_register_link_url']['#items'][0]['url']; ?>"><?php print $content['field_register_link_url']['#items'][0]['url']; ?></a></div>
		  <?php } ?>		  
		  <div class="post-area"><strong>Area of Training: </strong><a href="/<?php $area=taxonomy_term_load($content['field_course_type']['#items'][0]['tid']);$area_path=taxonomy_term_uri($area);print $area_path['path']; ?>"><?php print $area->name; ?></a></div>
	  </div>
	  <div class="post-summary"><p><strong>Course Summary</strong><br/> <?php print render($content['field_course_summary']['#items'][0]['safe_value']);?></p></div>	  
	  <?php if (isset($content['field_key_benefits']['#items'][0]['safe_value']) && !empty($content['field_key_benefits']['#items'][0]['safe_value'])) { ?>
		<div class="post-key-benefits"><p><strong>Key benefits</strong><br/><?php print render($content['field_key_benefits']['#items'][0]['safe_value']); ?></p></div>
	  <?php } else { ?>
		<div class="post-benefits"><p><strong>Course Benefits</strong><br/><?php print render($content['field_course_benefits']['#items'][0]['safe_value']); ?></p></div>
	  <?php } ?>	  
      <div class="post-body"> <?php print render($content['body']['#items'][0]['safe_value']); ?> </div>
      <?php if (isset($content['field_contact_us_email']['#items'][0]['email']) && !empty($content['field_contact_us_email']['#items'][0]['email'])) { ?>
		<div class="applynow"> <a class="button" href="mailto:<?php print $content['field_contact_us_email']['#items'][0]['email']; ?>" target="_top"> Apply Now</a> </div>
	  <?php } ?>
    </div>
  </div>
  <?php print render($content['links']); ?> 
  <?php print render($content['comments']); ?> 
  </div