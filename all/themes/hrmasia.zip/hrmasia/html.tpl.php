<!DOCTYPE html>
<html<?php print $html_attributes; ?>>
<head>
<?php print $head; ?>
<title><?php print $head_title; ?></title>
<meta name="description" content="HRM Asia Magazine reports news and information needed to develop and manage HR strategies in Singapore that improve bottom line results for HR decisions.">
<meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
<?php print $styles; ?>
<link href='http://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'>
<?php print $scripts; ?>
<script>
  googletag.cmd.push(function() {
    googletag.defineSlot('/56036150/him_billboard', [970, 280], 'div-gpt-ad-1472994367402-0').addService(googletag.pubads());
    googletag.pubads().enableSingleRequest();
    googletag.enableServices();
  });
</script>

</head>
 
<body<?php print $body_attributes;?>>
<!--<div id="preloader">
    <div id="status">&nbsp;</div>
</div>-->
<?php print $page_top; ?>
<?php print $page; ?>
<?php print $page_bottom; ?>

<footer>
<?php
global $user;
if($user->uid != 0){
  $u = profile2_load_by_user($user, "main");
  $append = null;
  
  if(isset($u->field_employe_size['und'][0]['value'])){
    $append .= "&comsize=".$u->field_employe_size['und'][0]['value'];
  }

  if(isset($u->field_country['und'][0]['value'])){
    $append .= "&country=".$u->field_country['und'][0]['value'];
  }

  if(arg(0) == "taxonomy" && arg(2) == 266){
    $append .= "&joblvl=1";
  }
  if(arg(0) == "taxonomy" && arg(2) == 256){
    $append .= "&joblvl=2";
  }
  if(arg(0) == "taxonomy" && arg(2) == 261){
    $append .= "&joblvl=3";
  }

  if(explode("/",$_SERVER['REQUEST_URI'])[1] == "article-subcategory"){
    $append .= "&cat=".explode("/",$_SERVER['REQUEST_URI'])[2];
  }

  if(arg(0) == "node" && is_numeric(arg(1))){
    $node = node_load(arg(1));
    
    if($node->type == "article"){
  	  $cat = taxonomy_term_load($node->field_category['und'][0]['tid']);
      $append .= "&cat=".$cat->name;
      $subcat = taxonomy_term_load($node->field_sub_category['und'][0]['tid']);
      $append .= "&subcat=".$subcat->name;
    }

    if($node->type == "news"){
      $cat = taxonomy_term_load($node->field_tags['und'][0]['tid']);
      $append .= "&cat=".$cat->name;
    }
  } //node end

  $mainexcat = explode("/",$_SERVER['REQUEST_URI'])[1];
  if($mainexcat == "news" || $mainexcat == "hrm-events" || $mainexcat == "jobs" || $mainexcat == "courses-categories" || $mainexcat == "hrmtv"){
  	$append .= "&maincat=".$mainexcat;
  }

  print '<script type="text/javascript" src="http://ps.eyeota.net/pixel?pid=1mpf2m0&sid=hrm&t=js'.$append.'"></script>';
}else{

  $appends = null;
  if(explode("/",$_SERVER['REQUEST_URI'])[1] == "article-subcategory"){
    $appends .= "&cat=".explode("/",$_SERVER['REQUEST_URI'])[2];
  }

  $mainexcat = explode("/",$_SERVER['REQUEST_URI'])[1];
  if($mainexcat == "news" || $mainexcat == "hrm-events" || $mainexcat == "jobs" || $mainexcat == "courses-categories" || $mainexcat == "hrmtv"){
  	$appends .= "&maincat=".$mainexcat;
  }

  if(arg(0) == "node" && is_numeric(arg(1))){
    $node = node_load(arg(1));
    if($node->type == "article"){
  	  $cat = taxonomy_term_load($node->field_category['und'][0]['tid']);
      $appends .= "&cat=".$cat->name;
      $subcat = taxonomy_term_load($node->field_sub_category['und'][0]['tid']);
      $appends .= "&subcat=".$subcat->name;
    }

    if($node->type == "news"){
      $cat = taxonomy_term_load($node->field_tags['und'][0]['tid']);
      $appends .= "&cat=".$cat->name;
    }
  }//end nodes
  
  if($appends != null){
    print '<script type="text/javascript" src="http://ps.eyeota.net/pixel?pid=1mpf2m0&sid=hrm&t=js'.$appends.'"></script>';
  } 	
}
?>
</footer>
</body>
</html>
