 
<div id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?> clearfix"<?php print $attributes; ?>>
  <?php global $user; ?>
  <?php print $user_picture; ?>



  <?php if ($display_submitted): ?>
    <div class="submitted">
      <?php print $submitted; ?>
    </div>
  <?php endif; ?>

  <div class="content"<?php print $content_attributes; ?>>
    <?php
      // We hide the comments and links now so that we can render them later.
      hide($content['comments']);
      hide($content['links']);
	    $share_block = module_invoke('sharethis','block_view','sharethis_block');
	    $subscribe_block = module_invoke('notifications_ui','block_view','subscriptions');
    ?>

    <div class="acticle-top">
      <!--<div class="post-category"> <?php print render($content['field_category']); ?> </div>-->
      <div class="post-title"> <h1> <?php print $node->title; ?> </h1> 
      <div class="social-share-post"> <?php print render($share_block['content']); ?> </div>
    </div>
    
    <div class="author-date"> 
      <span class="author"><?php print render($content['field_author_name']);  ?></span> - <span class="post-date"><?php print render($content['field_date']) ;?></span> </div>
    </div>
    
    
      <div class="post-image img-responsive">
      <a target="_blank" href="/sites/default/files/field/images/<?php print $node->field_image['und'][0]['filename']; ?>"><?php print render($content['field_image']); ?>
   </a>
<!-- <a href="/sites/default/files/field/images/<?php //print $node->field_image['und'][0]['filename']; ?>" target="_blank" style="float: left;">
        View larger image <img width="28px" src="http://hrmasia.com/sites/default/files/zoom-tool.png" style="float: right; padding-left: 9px; margin-bottom: 11px;"></a>-->
 </div>
      <div class="post-summary"> 
        <?php //print render($node->body[$node->language][0]['safe_summary']);  ?> 
        <?php print render($content['field_article_summary']); ?>
        
        <div class="tittle-menu">
          <h6 style="font-size: 15px; margin: 0px 0px 6px; border-bottom: 1px solid rgb(170, 170, 170); padding-bottom: 7px; width: 48%;">Jump Menu</h6>
        <?php
          foreach($node->field_article_content['und'] as $event_details){
            $event_collection_value = field_collection_item_load($event_details['value'], $reset = FALSE);
            print '<a href="#jump'.$event_collection_value->item_id.'">'.$event_collection_value->field_title_in['und'][0]['value'].'</a>';
          }   
        ?> 
      </div>
      </div>
    
    	<div class="post-body"> 
        <i>
          <?php
            //print render($content['field_article_summary']); 
          ?>
        </i>
    		<?php
    			//print render($content['body']);
          foreach($node->field_article_content['und'] as $event_details){
            $event_collection_value = field_collection_item_load($event_details['value'], $reset = FALSE);
            print '<div id="jump'.$event_collection_value->item_id.'">';
            print '<h3>'.$event_collection_value->field_title_in['und'][0]['value'].'</h3>';
            print $event_collection_value->field_content['und'][0]['value'];
            print '</div>';
          }   
    		?> 
    	</div>    

<div class="ibm-capm" style="float: left; background: rgb(247, 247, 247) none repeat scroll 0% 0%; padding: 28px; margin: 40px 0px 3px;">
<div class="block-content-title" style="border-bottom: 1px solid rgb(204, 204, 204); width: 50%; margin-bottom: 35px; padding-bottom: 15px;">Social tools for collaboration</div>
<a href="http://hrmasia.com/content/social-tools-collaboration" target="_blank">
<img src="http://www.hrmasia.com/sites/default/files/ibm-newman.jpg" width="450"></a>
<p> Today's modern HR teams want to use social tools within their workplaces to more effectively collaborate with their talent and colleagues. Mat Newman, IBM's Collaboration Executive in Southeast Asia, explains how the company's product offerings are being tailored with this purpose in mind.</p>
</div>
<!--<div class="ibm-capm" style="float: left; background: rgb(247, 247, 247) none repeat scroll 0% 0%; padding: 28px; margin: 40px 0px 3px;">
<div class="block-content-title" style="border-bottom: 1px solid rgb(204, 204, 204); width: 50%; margin-bottom: 35px; padding-bottom: 15px;">Reinventing engagement</div>
<a href="http://hrmasia.com/content/reinventing-engagement" target="_blank">
<img src="http://www.hrmasia.com/sites/default/files/ann-shen-big.jpg" width="450"></a>
<p> Ann Shen, HR Director for IBM in the ASEAN region, shares how the company's HR team has rebuilt its employee engagement policies and performance management structure.</p></div>-->


    <!--<div class="related-articles">
    </div>-->

    <!-- Add pager at the bottom -->
  <div class="news-pager related-articles">
    <ul>
      <li class="views-row-odd">
      <?php 
        if($content['flippy_pager']['#list']['prev']['nid']){
          print render(prev_next('prev', $content['flippy_pager']['#list']['prev']['nid']));
        }?>
      </li>
      <li class="views-row-even"> 
        <?php 
        if($content['flippy_pager']['#list']['next']['nid']){
          print render(prev_next('next', $content['flippy_pager']['#list']['next']['nid']));
        }
        ?>
      </li>
    </ul>
  </div>
    
    <div class="disqus-block"> <?php //print render($content['disqus']); ?>  
    
  </div>
  
  <?php print render($content['links']); ?>
  <?php print render($content['comments']); ?>

</div>
</div>

<style>
.post-body > div {
    border-top: 1px dotted #ccc;
    float: left;
    padding-bottom: 15px;
    padding-top: 20px;
}
.post-summary {
  font-weight: 500 !important;
  margin: 15px 0 !important;
  float: left;
}
.post-summary .field-name-field-article-summary{
  float: left;
  width: 50%
}
.tittle-menu {
  float: right;
  text-align: left;
  width: 40%;
}
.tittle-menu > a {
  float: left;
  width: 100%;
}
</style>
